//
//  AppDelegate.h
//  VoodooHdaSettingsLoader
//
//  Created by Ben on 10/11/11.
//  Copyright (c) 2011-2013 VoodooHDA. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate> {
}
- (void)applicationDidFinishLaunching:(NSNotification *)aNotification;

@end
