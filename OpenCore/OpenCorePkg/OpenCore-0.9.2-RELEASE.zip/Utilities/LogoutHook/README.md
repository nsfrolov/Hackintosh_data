# LogoutHook

## Script

### Usage
```./Launchd.command```

### Installation
```./Launchd.command install```

### Status
```./Launchd.command status```

Shows non-empty daemon pid only, if installed with default settings.

### Log
```/var/log/org.acidanthera.nvramhook.launchd/launchd.log```
